<?php

    // 获取参数
    $cip = $_GET['cip'];

    $url = "http://api.map.baidu.com/highacciploc/v1?qcip=".$cip."&qterm=pc&ak=WBAeXsAUPdhTGGpyRNhq4Mq66MpzkL0M&coord=bd09ll";

    // 请求内容
    $content_sting = file_get_contents($url);

    // echo "var result = $content_sting;";

    echo $content_sting;
?>
