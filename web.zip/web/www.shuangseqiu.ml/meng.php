<!DOCTYPE html>
<!-- saved from url=(0055)http://localhost:63342/%E7%A5%9E%E8%B5%8Bssq/index.html -->
<html lang="en"><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    
    <title>每天都有惊喜</title>

<?php
/**
 * Created by PhpStorm.
 * User: xuanyuanshenfu
 * Date: 2017/1/16
 * Time: 下午3:33
 */

$ip = $_SERVER['REMOTE_ADDR'];
//print_r($_SERVER);EXIT;

//echo "你的IP：$ip";
$text_file = 'meng.txt';

$str = file_get_contents($text_file);

$str += 1; 

echo "访问次数：$str";

$file_handle = fopen($text_file, "w");

fwrite($file_handle, $str);

?>



<br/><br/><br/>

已经卸载贴吧app，无法回复，等待时机，东山再起。<br/><br/>

源码在：
<a href="https://pan.baidu.com/s/1dEPRq61 ">https://pan.baidu.com/s/1dEPRq61 </a>
<br/>
<br/>
可以任意下载运行、修改、传播。<br/><br/>

手机直接打开链接可能无法运行，请在电脑用浏览器打开。<br/>






</html>
